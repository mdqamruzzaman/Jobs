package com.jobs.exception;

import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.jobs.model.MessageResponse;

import io.jsonwebtoken.ExpiredJwtException;
import lombok.extern.slf4j.Slf4j;

@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@Slf4j
public class RestExceptionHandler {

	@ResponseStatus(HttpStatus.UNAUTHORIZED)
	@ExceptionHandler(UnauthorizedException.class)
	public ResponseEntity<?> handleUnauthorizedExceptions(UnauthorizedException ex) {
		log.error("Unauthorized request...");
		return ResponseEntity.badRequest()
				.body(new MessageResponse("Unauthorized request. Login again...", HttpStatus.UNAUTHORIZED));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MissingRequestHeaderException.class)
	public ResponseEntity<?> handleMissingRequestHeaderException(MissingRequestHeaderException ex) {
		log.error("Required Bearer token....");
		return ResponseEntity.badRequest().body(new MessageResponse("Required Bearer token", HttpStatus.BAD_REQUEST));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(ExpiredJwtException.class)
	public ResponseEntity<?> handleExpiredJwtException(ExpiredJwtException ex) {

		log.error("Token has expired");
		return ResponseEntity.badRequest().body(new MessageResponse("Token has expired", HttpStatus.BAD_REQUEST));
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(UserAlreadyPresent.class)
	public ResponseEntity<?> handleUserAlreadyPresent(UserAlreadyPresent ex) {
		log.error("Bad request...");
		return ResponseEntity.badRequest().body(new MessageResponse("User Already Present!!", HttpStatus.BAD_REQUEST));
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(UserDetailsNotFound.class)
	public ResponseEntity<?> handleUserDetailsNotFound(UserDetailsNotFound ex) {
		log.error("Not Found request...");
		return ResponseEntity.badRequest().body(new MessageResponse("User Details Not Found!!", HttpStatus.NOT_FOUND));
	}

	@ResponseStatus(HttpStatus.NOT_FOUND)
	@ExceptionHandler(JobsDetailsNotFound.class)
	public ResponseEntity<?> handleJobsDetailesNotFound(JobsDetailsNotFound ex) {
		log.error("Not Found Request");
		return ResponseEntity.badRequest().body(new MessageResponse("Jobs Details Not Found", HttpStatus.NOT_FOUND));
	}
}
