package com.jobs.exception;

public class JobsDetailsNotFound extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public JobsDetailsNotFound(String message) {
		super(message);
	}

}
