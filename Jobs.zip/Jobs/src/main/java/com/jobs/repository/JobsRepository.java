package com.jobs.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.jobs.model.Jobs;
import java.util.List;

@Repository
public interface JobsRepository extends JpaRepository<Jobs, Integer> {

	// Get Jobs Details By Types
	public List<Jobs> findByTypes(String types);

	// Get Jobs Details By Technology Required
	public List<Jobs> findByTechnologyRequired(String technologyRequired);

	// Get Jobs Details By Salary
	public List<Jobs> findBySalary(String salary);

	// Get Jobs Details By Title
	public List<Jobs> findByTitle(String title);

	// Get Jobs Details By Address
	public List<Jobs> findByAddress(String address);

}
