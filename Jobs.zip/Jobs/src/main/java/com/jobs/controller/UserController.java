package com.jobs.controller;

import java.security.Principal;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobs.model.Role;
import com.jobs.model.User;
import com.jobs.model.UserRole;
import com.jobs.serviceImpl.UserServiceImpl;

@RestController
@RequestMapping("/user")
@CrossOrigin("*")
public class UserController {

	@Autowired
	private UserServiceImpl userServiceImpl;

	// Create User Registration
	@PostMapping("/create")
	public ResponseEntity<User> createUser(@RequestBody User user) {

		Set<UserRole> roles = new HashSet<>();

		// Role define
		Role role = new Role();
		role.setRoleId(45);
		role.setRoleName("NORMAL");

		// UserRole define
		UserRole userRole = new UserRole();
		userRole.setUser(user);
		userRole.setRole(role);

		// add userRole into role
		roles.add(userRole);

		return new ResponseEntity<User>(userServiceImpl.createUser(user, roles), HttpStatus.CREATED);
	}

	// Current User
	@GetMapping("/currentUser")
	public ResponseEntity<User> getCurrentUser(Principal principal) {
		return new ResponseEntity<User>(userServiceImpl.getCurrentUser(principal.getName()), HttpStatus.OK);
	}

	// Get User By Username
	@GetMapping("/getUserByUsername/{username}")
	public ResponseEntity<User> getUserByUsername(@PathVariable("username") String username) {
		return new ResponseEntity<User>(userServiceImpl.getUser(username), HttpStatus.OK);
	}

	// Get User By ID
	@GetMapping("/getUserById/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id") int id) {
		return new ResponseEntity<User>(userServiceImpl.getUserByID(id), HttpStatus.OK);
	}

	// Get All User
	@GetMapping("/getAllUser")
	public ResponseEntity<List<User>> getAllUser() {
		return new ResponseEntity<List<User>>(userServiceImpl.getAllUser(), HttpStatus.OK);
	}

	// Update User
	@PutMapping("/updateUser/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id") int id, @RequestBody User user) {
		return new ResponseEntity<User>(userServiceImpl.updateUser(id, user), HttpStatus.OK);
	}

	// Delete User
	@DeleteMapping("/deleteUser/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable("id") int id) {
		userServiceImpl.deleteUser(id);
		return new ResponseEntity<String>("User Deleted", HttpStatus.OK);
	}

}
