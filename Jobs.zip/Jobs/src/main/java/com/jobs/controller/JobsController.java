package com.jobs.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.jobs.model.Jobs;
import com.jobs.serviceImpl.JobsServiceImpl;

@RestController
@RequestMapping(value = "jobs")
@CrossOrigin("*")
public class JobsController {

	@Autowired
	private JobsServiceImpl jobsServiceImpl;

	// Create Job
	@PostMapping(value = "/create")
	public ResponseEntity<Jobs> create(@RequestBody Jobs jobs) {
		return new ResponseEntity<Jobs>(jobsServiceImpl.createJobs(jobs), HttpStatus.CREATED);
	}

	// Get All Jobs
	@GetMapping("/getAllJobs")
	public ResponseEntity<List<Jobs>> getAllJobs() {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.getAllJobs(), HttpStatus.OK);
	}

	// Get Jobs By ID
	@GetMapping("/getJobsById/{id}")
	public ResponseEntity<Jobs> getJobsByID(@PathVariable("id") int id) {
		return new ResponseEntity<Jobs>(jobsServiceImpl.getJobsById(id), HttpStatus.OK);
	}

	// Update Job By ID
	@PutMapping("/updateJobs/{id}")
	public ResponseEntity<Jobs> updateJobs(@PathVariable("id") int id, @RequestBody Jobs jobs) {
		return new ResponseEntity<Jobs>(jobsServiceImpl.updateJobs(id, jobs), HttpStatus.OK);
	}

	// Delete Job By ID
	@DeleteMapping("/deleteJobs/{id}")
	public ResponseEntity<?> deleteJobs(@PathVariable("id") int id) {
		jobsServiceImpl.deleteJobs(id);
		return new ResponseEntity<String>("Jobs Deleted", HttpStatus.OK);
	}

	// Get Job By Types
	@GetMapping("/getJobsByTypes/{types}")
	public ResponseEntity<List<Jobs>> getJobsByTypes(@PathVariable("types") String types) {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.findByTypes(types), HttpStatus.OK);
	}

	// Get Job By TechnologyRequired
	@GetMapping("/getJobsByTechnologyRequired/{technologyRequired}")
	public ResponseEntity<List<Jobs>> getJobsByTechnologyRequired(
			@PathVariable("technologyRequired") String technologyRequired) {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.findByTechnologyRequired(technologyRequired),
				HttpStatus.OK);
	}

	// Get Job By Adress
	@GetMapping("/getJobsByAddress/{address}")
	public ResponseEntity<List<Jobs>> getJobsByAddress(@PathVariable("address") String address) {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.findByAddress(address), HttpStatus.OK);
	}

	// Get Job By Salary
	@GetMapping("/getJobsBySalary/{salary}")
	public ResponseEntity<List<Jobs>> getJobsBySalary(@PathVariable("salary") String salary) {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.findBySalary(salary), HttpStatus.OK);
	}

	// Get Job By Title
	@GetMapping("/getJobsByTitle/{title}")
	public ResponseEntity<List<Jobs>> getJobsByTitle(@PathVariable("title") String title) {
		return new ResponseEntity<List<Jobs>>(jobsServiceImpl.findByTitle(title), HttpStatus.OK);
	}
}
