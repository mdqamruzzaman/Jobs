package com.jobs.service;

import java.util.List;

import com.jobs.model.Jobs;

public interface JobsService {

	// Create Jobs
	public Jobs createJobs(Jobs jobs);

	// Get Job By ID
	public Jobs getJobsById(int jobId);

	// Get All Job
	public List<Jobs> getAllJobs();

	// Update Jobs
	public Jobs updateJobs(int jobid, Jobs jobs);

	// Delete Jobs
	public void deleteJobs(int jobid);

	// Get Jobs Details By Types
	public List<Jobs> findByTypes(String types);

	// Get Jobs Details By Technology Required
	public List<Jobs> findByTechnologyRequired(String technologyRequired);

	// Get Jobs Details By Salary
	public List<Jobs> findBySalary(String salary);

	// Get Jobs Details By Title
	public List<Jobs> findByTitle(String title);

	// Get Jobs Details By Address
	public List<Jobs> findByAddress(String address);
}
