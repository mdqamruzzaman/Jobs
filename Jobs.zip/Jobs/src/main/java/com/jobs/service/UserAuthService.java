package com.jobs.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.jobs.model.auth.AuthResponse;
import com.jobs.model.auth.UserModel;
import com.jobs.model.auth.UserToken;

public interface UserAuthService extends UserDetailsService {

	public UserToken login(UserModel userModel);

	public AuthResponse getValidity(String token);
}
