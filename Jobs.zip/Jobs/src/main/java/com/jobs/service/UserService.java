package com.jobs.service;

import java.util.List;
import java.util.Set;

import com.jobs.model.User;
import com.jobs.model.UserRole;

public interface UserService {

	// creating user
	public User createUser(User userEntity, Set<UserRole> userRoles);

	// get user by username
	public User getUser(String username);

	// get user by username
	public User getUserByID(int id);

	// delete user by username
	public void deleteUser(int userId);

	// update user by username
	public User updateUser(int userId, User userEntity);

	// get all user
	public List<User> getAllUser();

	// get the current user
	public User getCurrentUser(String username);
}
