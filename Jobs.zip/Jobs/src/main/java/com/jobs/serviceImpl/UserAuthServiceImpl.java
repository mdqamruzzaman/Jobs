package com.jobs.serviceImpl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.jobs.exception.UnauthorizedException;
import com.jobs.jwt.JwtUtil;
import com.jobs.model.User;
import com.jobs.model.auth.AuthResponse;
import com.jobs.model.auth.UserModel;
import com.jobs.model.auth.UserToken;
import com.jobs.repository.UserRepository;
import com.jobs.service.UserAuthService;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserAuthServiceImpl implements UserAuthService {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private JwtUtil jwtUtil;

	@Override
	public UserDetails loadUserByUsername(String username) {
		// All Action to check the correctness of the UserID
		log.info("Inside Loadbyusername");
		try {
			User user = userRepository.findByUsername(username);
			return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
					new ArrayList<>());
		} catch (Exception e) {
			log.info("Authentication Failed");
			throw new UnauthorizedException("Invalid Username or password");
		}
	}

	@Override
	public UserToken login(UserModel userModel) {
		final UserDetails userDetails = loadUserByUsername(userModel.getUsername());
		UserToken userToken = new UserToken();

		// if the password matches
		if (userDetails.getPassword().equals(userModel.getPassword())) {
			log.info("Authentication Successfull... Generating Token...");

			// set the values for the token
			userToken.setUsername(userModel.getUsername());
			userToken.setId(userRepository.findByUsername(userModel.getUsername()).getId());
			userToken.setAuthToken(jwtUtil.generateToken(userDetails));

			return userToken;
		} else {
			log.info("Authentication Failed");
			throw new UnauthorizedException("Invalid Username or password");
		}
	}

	// Validates the JWT token
	@Override
	public AuthResponse getValidity(String token) {
		// retrieving the token ( removing the Bearer from the header)
		System.out.println(token);
		String token1 = token.substring(7);
		AuthResponse authResponse = new AuthResponse();
		// if valid
		if (jwtUtil.validateToken(token1)) {
			log.info("Token is valid");

			// extract the user name
			String username = jwtUtil.extractUsername(token1);

			// set the values for the response
			authResponse.setUsername(username);
			authResponse.setValid(true);
			authResponse.setId(userRepository.findByUsername(username).getId());
		} else {
			authResponse.setValid(false);
			log.error("Token is invalid or expired...");
		}

		return authResponse;
	}

}
