package com.jobs.serviceImpl;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobs.exception.UserAlreadyPresent;
import com.jobs.exception.UserDetailsNotFound;
import com.jobs.model.Role;
import com.jobs.model.User;
import com.jobs.model.UserRole;
import com.jobs.repository.RoleRepository;
import com.jobs.repository.UserRepository;
import com.jobs.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private RoleRepository roleRepository;

	// Registration
	@Override
	public User createUser(User userEntity, Set<UserRole> userRoles) {

		User local = this.userRepository.findByUsername(userEntity.getUsername());
		if (local != null) {
			System.out.println("User is already there !!");
			throw new UserAlreadyPresent("User already present !!");
		} else {
			// here user created
			for (UserRole ur : userRoles) {
				roleRepository.save(ur.getRole());
			}
			userEntity.getUserRoles().addAll(userRoles);
			local = this.userRepository.save(userEntity);
		}
		return local;
	}

	// Get User Username
	@Override
	public User getUser(String username) {

		User userDetails = userRepository.findByUsername(username);
		if (userDetails == null) {
			System.out.println("User is not available");
			throw new UserDetailsNotFound("User is not available");
		} else {
			// Return user Details
			return userDetails;
		}
	}

	// Get User By ID
	@Override
	public User getUserByID(int id) {

		Optional<User> userDetails = userRepository.findById(id);
		if (userDetails.isPresent()) {
			return userDetails.get();
		} else {
			throw new UserDetailsNotFound("User Details not found");
		}
	}

	// Delete User By ID
	@Override
	public void deleteUser(int userId) {
		Optional<User> userDetails = userRepository.findById(userId);
		if (userDetails.isPresent()) {
			System.out.println("User Deleted");
			userRepository.deleteById(userId);
		} else {
			throw new UserDetailsNotFound("User Details not found");
		}
	}

	// Update User By ID
	@Override
	public User updateUser(int userId, User userEntity) {
		Optional<User> userDetails = userRepository.findById(userId);
		if (userDetails.isPresent()) {

			Set<UserRole> roles = new HashSet<>();

			// Role define
			Role role = new Role();
			role.setRoleId(45);
			role.setRoleName("NORMAL");

			// UserRole define
			UserRole userRole = new UserRole();
			userRole.setRole(role);

			// add userRole into role
			roles.add(userRole);

			userDetails.get().setId(userId);
			userDetails.get().setUsername(userEntity.getUsername());
			userDetails.get().setPassword(userEntity.getPassword());
			userDetails.get().setFirstname(userEntity.getFirstname());
			userDetails.get().setLastname(userEntity.getLastname());
			userDetails.get().setAddress(userEntity.getAddress());
			userDetails.get().setEmail(userEntity.getEmail());
			userDetails.get().setEnabled(true);
			userDetails.get().setGender(userEntity.getGender());
			userDetails.get().setPhone(userEntity.getPhone());
			userDetails.get().setUserRoles(roles);

			return userRepository.save(userDetails.get());

		} else {
			throw new UserDetailsNotFound("User Details not found");
		}
	}

	// Get All User
	@Override
	public List<User> getAllUser() {

		return userRepository.findAll();
	}

	// Get Logged In User
	@Override
	public User getCurrentUser(String username) {

		User userDetails = userRepository.findByUsername(username);
		if (userDetails == null) {
			System.out.println("User is not available");
			throw new UserDetailsNotFound("User Details not found ");
		} else {
			// here get user
			return userDetails;
		}
	}

}
