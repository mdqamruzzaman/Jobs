package com.jobs.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jobs.exception.JobsDetailsNotFound;
import com.jobs.model.Jobs;
import com.jobs.repository.JobsRepository;
import com.jobs.service.JobsService;

@Service
public class JobsServiceImpl implements JobsService {

	@Autowired
	private JobsRepository jobsRepository;

	// Create Job
	@Override
	public Jobs createJobs(Jobs jobs) {
		return jobsRepository.save(jobs);
	}

	// Get Jobs By ID
	@Override
	public Jobs getJobsById(int jobId) {
		Optional<Jobs> jobDetails = jobsRepository.findById(jobId);
		if (jobDetails.isPresent()) {
			return jobDetails.get();
		} else {
			throw new JobsDetailsNotFound("Jobs Details not Found");
		}
	}

	// Get All Jobs
	@Override
	public List<Jobs> getAllJobs() {
		return jobsRepository.findAll();
	}

	// Update Jobs By ID
	@Override
	public Jobs updateJobs(int jobid, Jobs jobs) {
		Optional<Jobs> jobsDetails = jobsRepository.findById(jobid);
		if (jobsDetails.isPresent()) {
			Jobs jobs2 = new Jobs();

			jobs2.setJobID(jobid);
			jobs2.setTitle(jobs.getTitle());
			jobs2.setAddress(jobs.getAddress());
			jobs2.setDescription(jobs.getDescription());
			jobs2.setProfilePhoto(jobs.getProfilePhoto());
			jobs2.setSalary(jobs.getSalary());
			jobs2.setTechnologyRequired(jobs.getTechnologyRequired());
			jobs2.setTypes(jobs.getTypes());

			return jobsRepository.save(jobs2);
		} else {
			throw new JobsDetailsNotFound("Jobs Details Not Found");
		}
	}

	// Delete Job By ID
	@Override
	public void deleteJobs(int jobid) {
		Optional<Jobs> jobDetails = jobsRepository.findById(jobid);
		if (jobDetails.isPresent()) {
			System.out.println("Job Deleted");
			jobsRepository.deleteById(jobid);
		} else {
			throw new JobsDetailsNotFound("Jobs Details Not Found");
		}
	}

	// Get Jobs By JobTypes
	@Override
	public List<Jobs> findByTypes(String types) {
		List<Jobs> jobs = jobsRepository.findByTypes(types);
		if (jobs == null) {
			throw new JobsDetailsNotFound("Jobs Details Not Found With Types");
		} else {
			return jobs;
		}
	}

	// Get Jobs By TechnologyRequired
	@Override
	public List<Jobs> findByTechnologyRequired(String technologyRequired) {
		List<Jobs> jobs = jobsRepository.findByTechnologyRequired(technologyRequired);
		if (jobs == null) {
			throw new JobsDetailsNotFound("Jobs Details Not Found with Technology Required");
		} else {
			return jobs;
		}
	}

	// Get Jobs By Salary
	@Override
	public List<Jobs> findBySalary(String salary) {
		List<Jobs> jobs = jobsRepository.findBySalary(salary);
		if (jobs == null) {
			throw new JobsDetailsNotFound("Jobs Details Not Found With Salary");
		} else {
			return jobs;
		}
	}

	// Get Jobs By Title
	@Override
	public List<Jobs> findByTitle(String title) {
		List<Jobs> jobs = jobsRepository.findByTitle(title);
		if (jobs == null) {
			throw new JobsDetailsNotFound("Jobs Details Not Found with Title");
		} else {
			return jobs;
		}
	}

	// Get Jobs By Address
	@Override
	public List<Jobs> findByAddress(String address) {
		List<Jobs> jobs = jobsRepository.findByAddress(address);
		if (jobs == null) {
			throw new JobsDetailsNotFound("Jobs Details Not Found With Address");
		} else {
			return jobs;
		}
	}
}
