package com.jobs.model;

import java.io.File;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class Jobs {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int jobID;
	private String title;
	private String address;
	private String salary;
	private String description;
	private String types;
	private String technologyRequired;
	private String link;
	private File profilePhoto;
}
