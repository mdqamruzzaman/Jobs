import React, { useState } from "react";
import { Drawer, IconButton, List, ListItem, ListItemText, makeStyles } from "@material-ui/core";
import MenuIcon from "@material-ui/icons/Menu";
import { Link } from "react-router-dom";
import { logout } from "../Services/LoginServices";

const useStyles = makeStyles(() => ({
    link: {
        textDecoration: "none",
        color: "blue",
        fontSize: "15px",
    },
    icon: {
        color: "white"
    }
}));

function SidebarDrawer() {
    const classes = useStyles();
    const [openDrawer, setOpenDrawer] = useState(false);
    return (
        <>
            <Drawer
                open={openDrawer}
                onClose={() => setOpenDrawer(false)}
            >
                <List>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        {/* <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/dashboard">Dashboard</Link>
                        </ListItemText> */}
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/profile">Profile</Link>
                        </ListItemText>
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/jobsapplied">Jobs Applied</Link>
                        </ListItemText>
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/jobsavailable">Jobs Available</Link>
                        </ListItemText>
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/learning">Learning</Link>
                        </ListItemText>
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/normal/setting">Settings</Link>
                        </ListItemText>
                    </ListItem>
                    <ListItem onClick={() => setOpenDrawer(false)}>
                        <ListItemText className={classes.link}>
                            <Link style={{textDecoration:"none",color:"black"}} to="/" onClick={logout}>Logout</Link>
                        </ListItemText>
                    </ListItem>
                </List>
            </Drawer>
            <IconButton onClick={() => setOpenDrawer(!openDrawer)}>
                <MenuIcon />
            </IconButton>
        </>
    );
}
export default SidebarDrawer;