import { myAxios } from "./Helper";
import { getToken } from "./LoginServices"

// Get Toke
const token = getToken();

// Add Job
export const addjobs = (jobsdata) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.post("/jobs/create", jobsdata, config).then((response) => response.data);
}

// Get All Jobs Available
export const getalljobs = () => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get("/jobs/getAllJobs", config).then((response) => response.data);
}

// Delete JobById
export const deleteJob = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.delete(`/jobs/deleteJobs/${id}`, config).then((response) => response.data);
}

// Update JobById
export const updateJobs = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`/jobs/updateJobs/${id}`, data, config).then((response) => response.data);
}

// Get Jobs by Types
export const getJobsByTypes = (types) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get(`/jobs/getJobsByTypes/${types}`, config).then((response) => response.data);
}

// Get Job By ID
export const getJobsByID = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get(`/jobs/getJobsById/${id}`, config).then((response) => response.data);
}