import { myAxios } from "./Helper";
import { getToken } from "./LoginServices";

// Get Token
const token = getToken();

// Sign Up of new User
export const signup = (user) => {
    return myAxios.post("user/create", user).then((response) => response.data);
}

// Get All User Details
export const getAllUsers = () => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get("/user/getAllUser", config).then((response) => response.data);
}

// Update Profile
export const updateProfile = (id, data) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.put(`/user/updateUser/${id}`, data, config).then((response) => response.data);
}

// Get User by ID
export const getUserByID = (id) => {
    const config = {
        headers: { Authorization: `Bearer ${token}` }
    };
    return myAxios.get(`/user/getUserById/${id}`, config).then((response) => response.data);
}