import './App.css';
import { Route, Routes } from 'react-router-dom';
import Footer from './Components/Footer/Footer';
import Navbar from './Components/Navbar/Navbar';
import Government from './Pages/Government';
import Home from './Pages/Home';
import Private from './Pages/Private';
import Normal from './Components/Normal/Normal';
import AuthGuard from './AuthGaurd/AuthGaurd';
import WelcomeNormal from './Components/Normal/WelcomeNormale';
import Admin from './Components/Admin/Admin';
import WelcomeAdmin from './Components/Admin/WelcomeAdmin';
import Courses from './Pages/Courses';
import Blogs from './Pages/Blogs';
import Dashboard from './Components/Normal/Dashboard';
import Profile from './Components/Normal/Profile';
import JobsApplied from './Components/Normal/JobsApplied';
import JobsAvailable from './Components/Normal/JobsAvailable';
import Learning from './Components/Normal/Learning';
import Setting from './Components/Normal/Setting';
import AddJobs from './Components/Admin/AddJobs';
import AddCourses from './Components/Admin/AddCourses';
import AdminDashboard from './Components/Admin/AdminDashboard';
import AdminProfile from './Components/Admin/AdminProfile';
import AdminSetting from './Components/Admin/AdminSetting';
import AdminJobsAvailable from './Components/Admin/AdminJobsAvailable';
import UpdateJobs from './Components/Admin/UpdateJobs';
import UpdateProfile from './Components/Admin/UpdateProfile';
import Applyjobs from './Components/Normal/ApplyJobs';
import UpdateNormalProfile from './Components/Normal/UpdateNormalProfile';

function App() {
  return (
    <div>
      <Navbar />
      <main className="App">
        <Routes>
          <Route path='/' element={<Home />} />
          <Route path='/governmentjobslist' element={<Government />} />
          <Route path='/privatejobslist' element={<Private />} />
          <Route path='/courses' element={<Courses />} />
          <Route path='/blogs' element={<Blogs />} />


          <Route path='admin' element={<AuthGuard><Admin /></AuthGuard>}>
            <Route path='' element={<AuthGuard><WelcomeAdmin /></AuthGuard>} />
            <Route path='dashboard' element={<AuthGuard><AdminDashboard /></AuthGuard>} />
            <Route path='profile' element={<AuthGuard><AdminProfile /></AuthGuard>} />
            <Route path='addjobs' element={<AuthGuard><AddJobs /></AuthGuard>} />
            <Route path='jobsavailable' element={<AuthGuard><AdminJobsAvailable /></AuthGuard>} />
            <Route path='addcourses' element={<AuthGuard><AddCourses /></AuthGuard>} />
            <Route path='setting' element={<AuthGuard><AdminSetting /></AuthGuard>} />
            <Route path='updateJobs/:id' element={<AuthGuard><UpdateJobs /></AuthGuard>} />
            <Route path='updateProfile/:id/:username' element={<AuthGuard><UpdateProfile /></AuthGuard>} />
          </Route>

          <Route path='normal' element={<AuthGuard><Normal /></AuthGuard>}>
            <Route path='' element={<AuthGuard><WelcomeNormal /></AuthGuard>} />
            <Route path='dashboard' element={<AuthGuard><Dashboard /></AuthGuard>} />
            <Route path='profile' element={<AuthGuard><Profile /></AuthGuard>} />
            <Route path='jobsapplied' element={<AuthGuard><JobsApplied /></AuthGuard>} />
            <Route path='jobsavailable' element={<AuthGuard><JobsAvailable /></AuthGuard>} />
            <Route path='learning' element={<AuthGuard><Learning /></AuthGuard>} />
            <Route path='setting' element={<AuthGuard><Setting /></AuthGuard>} />
            <Route path='applyjobs/:id' element={<AuthGuard><Applyjobs /></AuthGuard>} />
            <Route path='updateProfile/:id/:username' element={<AuthGuard><UpdateNormalProfile /></AuthGuard>} />
          </Route>
        </Routes>
      </main>
      <Footer />
    </div>
  );
}

export default App;