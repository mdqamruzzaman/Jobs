import React from 'react';
import { Avatar, Button, Paper, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/Grid';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import { signup } from '../../Services/UserServices';
import Swal from 'sweetalert2';

function Signup() {
    const paperStyle = { padding: 20, width: 300, margin: '0 auto' }
    const [state, setState] = React.useState({
        username: "",
        password: "",
        firstName: "",
        lastName: "",
        gender: "",
        email: "",
        phone: "",
        address: ""
    })
    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });

    }
    const handleSubmit = (event) => {
        event.preventDefault();
        // store user into data
        const data = {
            username: state.username,
            password: state.password,
            firstname: state.firstName,
            lastname: state.lastName,
            gender: state.gender,
            email: state.email,
            phone: state.phone,
            address: state.address,
        }
        // call api from backend 
        signup(data).then((response) => {
            Swal.fire('Sign Up Successfully Done! Please Login!', 'User id is ' + response.id, 'success');
        }).catch((error) => {
            Swal.fire('' + error.response.data.message, '', 'error');
        })
    }

    return (
        <Grid>
            <Paper style={paperStyle}>
                <Grid align="center">
                    <Avatar style={{ background: "#1bbd7e" }}>
                        <AddCircleOutlineIcon />
                    </Avatar>
                    <h2 style={{ margin: 0 }}>Sign Up</h2>
                    <Typography variant='caption'>Please fill this form to create an account !</Typography>
                </Grid>
                <form onSubmit={handleSubmit} style={{ margin: "10px" }}>
                    <TextField  fullWidth label='username' placeholder='Enter Username' variant="standard" name='username' value={state.username} type='text' required="true" onChange={handleChange} />
                    <TextField fullWidth label='password' placeholder='Enter Password' variant="standard" name='password' value={state.password} type='password' required="true" onChange={handleChange} />
                    <TextField fullWidth label='First Name' placeholder='Enter First Name' variant="standard" name='firstName' value={state.firstName} type='text' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Last Name' placeholder='Enter Last Name' variant="standard" name='lastName' value={state.lastName} type='text' required="true" onChange={handleChange} />
                    <FormControl>
                        <RadioGroup
                            row
                            // aria-labelledby="demo-row-radio-buttons-group-label"
                            name="gender"
                            onChange={handleChange}
                        >
                            <FormControlLabel value="female" control={<Radio />} label="Female" />
                            <FormControlLabel value="male" control={<Radio />} label="Male" />
                        </RadioGroup>
                    </FormControl>
                    <TextField fullWidth label='Email' placeholder='Enter Email' variant="standard" name='email' value={state.email} type='email' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Phone' placeholder='Enter Phone number' variant="standard" name='phone' value={state.phone} type='phone' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Address' placeholder='Enter Address' variant="standard" name='address' value={state.address} type='address' required="true" onChange={handleChange} />
                    <Button style={{ marginTop: "10px" }} type='submit' variant='contained' color='primary'>Sign up</Button>
                </form>
            </Paper>
        </Grid>
    );
}

export default Signup;