import React from "react";
import {
    AppBar,
    Toolbar,
    CssBaseline,
    Typography,
    makeStyles,
    useTheme,
    useMediaQuery,
} from "@material-ui/core";
import { Link } from "react-router-dom";
import DrawerComponent from "../../Drawer/DrawerComponent";


const useStyles = makeStyles((theme) => ({
    navlinks: {
        marginLeft: theme.spacing(1),
        display: "flex",
    },
    logo: {
        flexGrow: "1",
        cursor: "pointer",
    },
    link: {
        textDecoration: "none",
        color: "white",
        fontSize: "15px",
        marginLeft: theme.spacing(5),
        "&:hover": {
            color: "yellow",
            borderBottom: "1px solid white",
        },
    },
}));

function Navbar() {
    const classes = useStyles();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("md"));

    return (
        <AppBar position="static">
            <CssBaseline />
            <Toolbar>
                <Typography variant="h5" className={classes.logo}>
                    <Link to={''} className={classes.link}>Dream Jobs</Link>
                </Typography>
                {isMobile ? (
                    <DrawerComponent />
                ) : (
                    <div className={classes.navlinks}>
                        <Link to="/courses" className={classes.link}>
                            Courses
                        </Link>
                        {/* <Link to="/governmentjobslist" className={classes.link}>
                            Government
                        </Link>
                        <Link to="/privatejobslist" className={classes.link}>
                            Private
                        </Link> */}
                        <Link to="/blogs" className={classes.link}>
                            Blogs
                        </Link>
                    </div>
                )}
            </Toolbar>
        </AppBar>
    );
}
export default Navbar;