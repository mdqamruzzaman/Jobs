import { Avatar, Button, Checkbox, FormControlLabel, Grid, Link, Paper, TextField, Typography } from "@mui/material";
import LockOutlinedIcon from '@mui/icons-material/LockOutlined';
import { useState } from "react";
import { getCurrentUser, getUserRole, login, loginUser, logout, setUser } from "../../Services/LoginServices";
import { useNavigate } from "react-router-dom";
import Swal from 'sweetalert2';

const Login = ({ handleChange }) => {
    const navigate = useNavigate();
    const paperStyle = { padding: 20, height: '80vh', width: 300, margin: '0 auto' }
    const [state, setState] = useState({
        username: "",
        password: ""
    });
    const handleChange1 = (event) => {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });
    }
    const handleSubmit = (event) => {
        event.preventDefault();
        // store user into data
        const data = {
            username: state.username,
            password: state.password
        }
        login(data).then((response) => {
            loginUser(response.authToken);

            // get Current User
            getCurrentUser().then((response) => {
                setUser(response);

                if (getUserRole() === 'ADMIN' || getUserRole() === 'admin') {
                    // admin dashboard
                    navigate("/admin");
                } else if (getUserRole() === 'NORMAL' || getUserRole() === 'normal') {
                    // normal dashboard
                    navigate("/normal");
                } else {
                    logout();
                }

            })

        }).catch((error) => {
            Swal.fire("Username & Password incorrect",+error,'error');
        })
    }
    return (
        <Grid>
            <Paper style={paperStyle}>
                <Grid align="center">
                    <Avatar style={{ background: "#1bbd7e" }}>
                        <LockOutlinedIcon />
                    </Avatar>
                    <h2>Sign In</h2>
                </Grid>
                <form onSubmit={handleSubmit}>
                    <TextField label="Username" placeholder="Enter Username" fullWidth variant="standard" type="text" name="username" value={state.username} required="true" onChange={handleChange1} />
                    <TextField label="Password" placeholder="Enter Password" fullWidth variant="standard" type="password" name="password" value={state.password} required="true" onChange={handleChange1} />
                    <FormControlLabel style={{ marginRight: "100px" }} control={
                        <Checkbox name="checked" color="primary" />
                    }
                        label="Remember me"
                    />
                    <Button type="submit" color="primary" variant="contained" fullWidth>Sign In</Button>
                </form>
                <Typography>
                    <Link href="#">Forget password?</Link>
                </Typography>
                <Typography>Do you have account?
                    <Link href="#" onClick={() => handleChange("event", 1)}>Sign Up</Link>
                </Typography>
            </Paper>
        </Grid>
    );
}

export default Login;