import { Sidebar, Menu, MenuItem } from "react-pro-sidebar";
// import DashboardIcon from '@mui/icons-material/Dashboard';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import WorkHistoryIcon from '@mui/icons-material/WorkHistory';
import WorkIcon from '@mui/icons-material/Work';
import './Sidemenu.css';
import LocalLibraryIcon from '@mui/icons-material/LocalLibrary';
import SettingsIcon from '@mui/icons-material/Settings';
import LogoutIcon from '@mui/icons-material/Logout';
import { useNavigate } from 'react-router-dom';
import { getUser, logout } from '../../Services/LoginServices';
import { Link } from "react-router-dom";
import { Typography, useMediaQuery, useTheme } from '@material-ui/core';
import SidebarDrawer from '../../Drawer/SidebarDrawer';

function Sidemenu() {
    const navigate = useNavigate();
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down("md"));
    const user = getUser();
    const handleLogout = () => {
        logout();
        navigate("/")
    }
    return (
            <Sidebar className="sidebar">
                <Menu>
                    <Typography>
                        <MenuItem className="menu1"><h2><Link style={{ textDecoration: "none", color: "black" }} to={""}><span><h4>Welcome <b>{user.firstname} !</b></h4></span></Link></h2></MenuItem>
                    </Typography>
                    {isMobile ? (
                        <SidebarDrawer />
                    ) : (
                        <div>
                            {/* <MenuItem><DashboardIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/dashboard"}>Dashboard</Link> </MenuItem> */}
                            <MenuItem><AccountCircleIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/profile"}>Profile</Link> </MenuItem>
                            <MenuItem><WorkHistoryIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/jobsapplied"}>Jobs Applied</Link> </MenuItem>
                            <MenuItem><WorkIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/jobsavailable"}>Jobs Available</Link> </MenuItem>
                            <MenuItem><LocalLibraryIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/learning"}>Learning</Link> </MenuItem>
                            <MenuItem><SettingsIcon fontSize='medium' /> <Link style={{ textDecoration: "none", color: "black" }} to={"/normal/setting"}>Settings</Link> </MenuItem>
                            <MenuItem onClick={handleLogout}><LogoutIcon fontSize='medium' />Logout </MenuItem>
                        </div>
                    )}
                </Menu>
            </Sidebar>
    );
}

export default Sidemenu;