import { Grid, Paper } from "@mui/material";

function Learning() {
    return ( 
        <Grid>
            <Paper>
                <h1>Learning</h1>
            </Paper>
        </Grid>
     );
}

export default Learning;