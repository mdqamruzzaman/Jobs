import {Outlet} from 'react-router-dom';
import Sidemenu from './Sidemenu';

function Normal() {
    return (
        <div className="bootstrap-wrapper">
            <div className="container">
                <div className="row">
                    <div className="col-md-3">
                        <Sidemenu/>
                    </div>
                    <div className="col-md-9">
                        <Outlet></Outlet>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Normal;