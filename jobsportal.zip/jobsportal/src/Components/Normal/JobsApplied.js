import { Grid, Paper } from "@mui/material";

function JobsApplied() {
    return ( 
        <Grid>
            <Paper>
                <h1>Jobs Applied List</h1>
            </Paper>
        </Grid>
     );
}

export default JobsApplied;