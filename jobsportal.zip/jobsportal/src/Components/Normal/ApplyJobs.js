import { Grid, Paper } from '@mui/material'
import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { getJobsByID } from '../../Services/JobsServices';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Swal from "sweetalert2";

function Applyjobs() {
    const { id } = useParams();
    const [jobs, setJobs] = useState([]);

    useEffect(() => {
        getJobsByID(id).then((response) => {
            setJobs(response)
        })
    }, [])

    const handleApply = () => {
        const url = jobs.link;
        Swal.fire({
            title: 'Do you want to Apply this Job?',
            showCancelButton: true,
            confirmButtonText: 'Yes',
            icon: "info"
        }).then((result) => {
            const newWindow = window.open(url, '_blank', 'noopener,noreferrer')
            if (newWindow) newWindow.opener = null
        })
    }
    return (
        <Grid style={{ margin: "15px" }}>
            <Paper elevation={10}>
                <Card>
                    <CardContent style={{ textAlign: "left" }}>
                        <Typography gutterBottom variant="h5" component="div">
                            <b>{jobs.title}</b>
                        </Typography>
                        <Typography>
                            <Button>Salary: <b> {jobs.salary} LPA CTC</b></Button>
                            <Button>Skills: <b> {jobs.technologyRequired}</b></Button>
                            <Button>Location: <b> {jobs.address}</b></Button>
                        </Typography>
                        <hr />
                        <Typography>
                            <p>Job Description:</p>
                            <span>{jobs.description}</span>
                        </Typography>
                    </CardContent>
                    <CardActions style={{ justifyContent: 'center' }}>
                        <Button size="medium" variant='contained' color='primary' style={{ margin: "10px" }} onClick={() => handleApply()}>Apply</Button>
                        <Button size="medium" variant='contained' color='error' href='/normal'>Back</Button>
                    </CardActions>
                </Card>
            </Paper>
        </Grid>
    );
}

export default Applyjobs;