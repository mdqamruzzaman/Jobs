import React from 'react';
import { Avatar, Button, Paper, TextField, Typography } from '@mui/material';
import Grid from '@mui/material/Grid';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import FormControlLabel from '@mui/material/FormControlLabel';
import FormControl from '@mui/material/FormControl';
import AddCircleOutlineIcon from '@mui/icons-material/AddCircleOutline';
import Swal from 'sweetalert2';
import { useParams } from 'react-router-dom';
import { updateProfile } from '../../Services/UserServices';

function UpdateNormalProfile() {
    const paperStyle = { padding: 20, width: 600, margin: '0 auto' }
    const { id } = useParams();
    const { username } = useParams();
    const [state, setState] = React.useState({
        password: "",
        firstName: "",
        lastName: "",
        gender: "",
        email: "",
        phone: "",
        address: ""

    })
    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });

    }

    const handleSubmit = (event) => {
        event.preventDefault();

        // store user into data
        const data = {
            password: state.password,
            firstname: state.firstName,
            lastname: state.lastName,
            gender: state.gender,
            email: state.email,
            phone: state.phone,
            address: state.address,
            username
        }
        // call api from backend 
        updateProfile(id, data).then((response) => {
            Swal.fire("Profile Update", '', 'success');
        })
    }

    return (
        <Grid style={{margin:"10px"}}>
            <Paper style={paperStyle}>
                <Grid align="center">
                    <Avatar style={{ background: "#1bbd7e" }}>
                        <AddCircleOutlineIcon />
                    </Avatar>
                    <h2 style={{ margin: 0 }}>Update Profile</h2>
                    <Typography variant='caption'>Please fill this form to Update an account !</Typography>
                </Grid>
                <form onSubmit={handleSubmit} style={{ margin: "10px" }}>
                    <TextField fullWidth label='First Name' placeholder='Enter First Name' variant="standard" name='firstName' value={state.firstName} type='text' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Last Name' placeholder='Enter Last Name' variant="standard" name='lastName' value={state.lastName} type='text' required="true" onChange={handleChange} />
                    <FormControl>
                        <RadioGroup
                            row
                            // aria-labelledby="demo-row-radio-buttons-group-label"
                            name="gender"
                            onChange={handleChange}
                        >
                            <FormControlLabel value="female" control={<Radio />} label="Female" />
                            <FormControlLabel value="male" control={<Radio />} label="Male" />
                        </RadioGroup>
                    </FormControl>
                    <TextField fullWidth label='Email' placeholder='Enter Email' variant="standard" name='email' value={state.email} type='email' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Phone' placeholder='Enter Phone number' variant="standard" name='phone' value={state.phone} type='phone' required="true" onChange={handleChange} />
                    <TextField fullWidth label='Address' placeholder='Enter Address' variant="standard" name='address' value={state.address} type='address' required="true" onChange={handleChange} />
                    <TextField fullWidth label='password' placeholder='Enter Password' variant="standard" name='password' value={state.password} type='password' required="true" onChange={handleChange} />
                    <Button style={{ marginTop: "10px" }} type='submit' variant='contained' color='primary'>Update Profile</Button>
                </form>
            </Paper>
        </Grid>
    );
}

export default UpdateNormalProfile;