import { useEffect, useState } from 'react';
import { getJobsByTypes } from '../../Services/JobsServices';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { Link } from 'react-router-dom';

function JobsAvailable() {
    const [privatejobs, setPrivatejobs] = useState([]);
    const [governmentjobs, setGovernmentJobs] = useState([]);

    // Get All Private Jobs
    useEffect(() => {
        getJobsByTypes("Private").then((response) => {
            setPrivatejobs(response)
        })
    }, []);

    // Get All Government Jobs
    useEffect(() => {
        getJobsByTypes("Government").then((response) => {
            setGovernmentJobs(response)
        })
    }, []);

    return (
        <div className="bootstrap-wrapper">
            <div className="container">
                <div className="row">
                    <div className="col md-6">
                        <h3><b>Private Jobs</b></h3>
                        {
                            privatejobs.map((privatejob) => (
                                <Card sx={{ maxWidth: 345 }} style={{ margin: "10px" }}>
                                    <CardMedia
                                        component="img"
                                        height="75"
                                        image="privatejob.profilePhoto"
                                    />
                                    <CardContent>
                                        <Typography gutterBottom variant="h5" component="div">
                                            <b>{privatejob.title}</b>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            Salary: <b>{privatejob.salary}</b> LPA CTC
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            Technology Required: <b>{privatejob.technologyRequired}</b>
                                        </Typography>
                                        <Typography variant="body2" color="text.secondary">
                                            Address: <b>{privatejob.address}</b>
                                        </Typography>
                                    </CardContent>
                                    <CardActions>
                                        <Button size="medium" variant="contained" color='primary'><Link to={`/normal/applyjobs/${privatejob.jobID}`} style={{ textDecoration: "none", color: "white" }}>Apply</Link></Button>
                                        <Button size="medium" variant="contained" color="success">Share</Button>
                                    </CardActions>
                                </Card>
                            ))
                        }
                    </div>
                    <div className="col md-6">
                        <h3><b>Government Jobs</b></h3>
                        <div className='container'>
                            {
                                governmentjobs.map((governmentjob) => (

                                    <Card sx={{ maxWidth: 345 }} style={{ margin: "10px" }}>
                                        <CardMedia
                                            component="img"
                                            height="75"
                                            image="governmentjob.profilePhoto"
                                        />
                                        <CardContent>
                                            <Typography gutterBottom variant="h5" component="div">
                                                <b>{governmentjob.title}</b>
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                Salary: <b>{governmentjob.salary}</b> LPA CTC
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                Skills: <b>{governmentjob.technologyRequired}</b>
                                            </Typography>
                                            <Typography variant="body2" color="text.secondary">
                                                Location: <b>{governmentjob.address}</b>
                                            </Typography>
                                        </CardContent>
                                        <CardActions>
                                            <Button size="medium" variant='contained' color='primary'><Link to={`/normal/applyjobs/${governmentjob.jobID}`} style={{ textDecoration: "none", color: "white" }}>Apply</Link></Button>
                                            <Button size="medium" variant="contained" color="success">Share</Button>
                                        </CardActions>
                                    </Card>
                                ))
                            }
                        </div>
                    </div>
                </div>
            </div >
        </div >
    );
}
export default JobsAvailable;