import { Grid, Paper } from "@mui/material";

function Dashboard() {
    return ( 
        <Grid>
            <Paper>
                <h1>Dashboard</h1>
            </Paper>
        </Grid>
     );
}

export default Dashboard;