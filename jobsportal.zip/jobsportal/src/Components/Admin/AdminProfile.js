import { Button, Grid, Paper } from "@mui/material";
import { getUser } from "../../Services/LoginServices";
import { Link } from "react-router-dom";
import { Table, TableCell, TableRow } from "@mui/material";
import { useEffect, useState } from "react";
import { getUserByID } from "../../Services/UserServices";

function AdminProfile() {
    const user = getUser();
    const [profile, setProfile] = useState([]);
    const id = user.id;

    // Get Profile By ID
    useEffect(() => {
        getUserByID(id).then((response) => {
            setProfile(response);
        })
    },[])

    return (
        <Grid>
            <Paper elevation={5}>
                <h1>Your Profile Details</h1>
                <div className="container" >
                    <div className="row">
                        <div className="col-md-10 offset-md-1">
                            <Table className="table">
                                <TableRow>
                                    <TableCell>Username</TableCell>
                                    <TableCell><b>{profile.username}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>UserID</TableCell>
                                    <TableCell><b>{profile.id}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>First Name</TableCell>
                                    <TableCell><b>{profile.firstname}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>Last Name</TableCell>
                                    <TableCell><b>{profile.lastname}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>Email</TableCell>
                                    <TableCell><b>{profile.email}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>Phone Number</TableCell>
                                    <TableCell><b>{profile.phone}</b></TableCell>
                                </TableRow>
                                <TableRow>
                                    <TableCell>Adress</TableCell>
                                    <TableCell><b>{profile.address}</b></TableCell>
                                </TableRow>
                            </Table>
                        </div>
                    </div>
                    <Button style={{ marginBottom: "10px" }} size="medium" variant='contained' color='primary'><Link style={{ color: "white", textDecoration: "none" }} to={`/admin/updateProfile/${profile.id}/${profile.username}`}>Update</Link></Button>
                </div>
            </Paper>
        </Grid>
    );
}

export default AdminProfile;