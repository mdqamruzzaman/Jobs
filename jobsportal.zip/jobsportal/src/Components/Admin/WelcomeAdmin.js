import * as React from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { deleteJob, getalljobs } from '../../Services/JobsServices';
import { useEffect, useState } from 'react';
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import { Collapse, styled } from '@mui/material';
import IconButton from '@mui/material/IconButton';

function WelcomeAdmin() {
    const [jobs, setJobs] = useState([]);
    const [expanded, setExpanded] = React.useState(false);

    // Get All User
    useEffect(() => {
        getalljobs().then((response) => {
            setJobs(response);
        })
    }, [])

    // Delete Jobs
    const handledelete = (id, e) => {
        deleteJob(id).then((response) => {
            Swal.fire(response, '', "success");
        }).catch((error) => {
            Swal.fire(error, '', 'error');
        })
    }
    // Expand more for Description
    const ExpandMore = styled((props) => {
        const { expand, ...other } = props;
        return <IconButton {...other} />;
    })(({ theme, expand }) => ({
        transform: !expand ? 'rotate(0deg)' : 'rotate(180deg)',
        marginLeft: 'auto',
        transition: theme.transitions.create('transform', {
            duration: theme.transitions.duration.shortest,
        }),
    }));

    const handleExpandClick = () => {
        setExpanded(!expanded);
    };

    return (
        <div className='row' style={{ marginTop: "10px" }}>
            {
                jobs.map((job) => (
                    <div className="col-md-3">
                        <Card sx={{ maxWidth: 345, maxHeight: 500 }} style={{ background: "white", marginBottom: "20px" }}>
                            <CardContent>
                                <Typography gutterBottom variant="h5" component="div">
                                    {job.title}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    {job.technologyRequired}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    {job.salary} LPA CTC
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                    {job.address}
                                </Typography>
                            </CardContent>
                            <CardActions>
                                <Button size="small" variant='contained' color='primary'><Link style={{ color: "white", textDecoration: "none" }} to={`/admin/updateJobs/${job.jobID}`}>Update</Link></Button>
                                <Button size="small" variant='contained' color='error' onClick={e => handledelete(job.jobID, e)}>Delete</Button>
                                <ExpandMore
                                    expand={expanded}
                                    onClick={handleExpandClick}
                                    aria-expanded={expanded}
                                    aria-label="show more"
                                >
                                    <ExpandMoreIcon />
                                </ExpandMore>
                            </CardActions>
                            <Collapse in={expanded} timeout="auto" unmountOnExit>
                                <CardContent>
                                    <Typography paragraph>Job Description:</Typography>
                                    <Typography paragraph>
                                        {job.description}
                                    </Typography>
                                </CardContent>
                            </Collapse>
                        </Card>
                    </div>
                ))
            }
        </div>
    );
}

export default WelcomeAdmin;