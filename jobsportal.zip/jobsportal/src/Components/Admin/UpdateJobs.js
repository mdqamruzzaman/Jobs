import { Avatar, Button, Grid, Paper, TextField, Typography } from "@mui/material";
import PostAddIcon from '@mui/icons-material/PostAdd';
import React, { useRef } from "react";
import JoditEditor from 'jodit-react';
import Swal from 'sweetalert2';
import { useParams } from 'react-router-dom';
import { updateJobs } from "../../Services/JobsServices";

function UpdateJobs() {
    const { id } = useParams();
    const editor = useRef(null);
    const paperStyle = { padding: 20, margin: '0 auto', background: `lightgrey` }
    const [description, setDescription] = React.useState('');
    const [state, setState] = React.useState({
        title: "",
        address: "",
        salary: "",
        technologyRequired: "",
        types: "",
        profilePhoto: ""
    })
    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });

    }
    const handleSubmit = (event) => {
        event.preventDefault();

        // store job data
        const data = {
            title: state.title,
            address: state.address,
            salary: state.salary,
            technologyRequired: state.technologyRequired,
            types: state.types,
            profilePhoto: state.profilePhoto,
            description
        }
        // call api from backend
        updateJobs(id, data).then((response) => {
            Swal.fire("Job Update", '', 'success');
        })
    }
    return (
        <Grid>
            <Paper style={paperStyle}>
                <Grid align="center">
                    <Avatar style={{ background: "blue" }}>
                        <PostAddIcon fontSize="medium" />
                    </Avatar>
                    <h2 style={{ margin: 0 }}>Update Job</h2>
                    <Typography variant="caption">Please fill this form to Add Job !</Typography>
                </Grid>
                <form onSubmit={handleSubmit}>
                    <TextField fullWidth label='Title' placeholder='Enter Company Name' variant="standard" name='title' value={state.title} type='text' required onChange={handleChange} />
                    <TextField fullWidth label='Address' placeholder="Enter Location" variant="standard" name="address" value={state.address} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Technology Required' placeholder="Enter Technology Required" variant="standard" name="technologyRequired" value={state.technologyRequired} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Types' placeholder="Enter Remote or In-Office" variant="standard" name="types" value={state.types} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Salary' placeholder="Enter Salary" variant="standard" name="salary" value={state.salary} type="text" required onChange={handleChange} />
                    <JoditEditor
                        ref={editor} value={description} onBlur={newDescription => setDescription(newDescription)} onChange={newDescription => { }}
                    />
                    <TextField fullWidth label='Profile Photo' placeholder="Upload Profile Photo" variant="standard" name="profilePhoto" value={state.profilePhoto} type="file" onChange={handleChange} />

                    <Button style={{ marginTop: "10px" }} type='submit' variant='contained' color='primary'>Update Job</Button>
                    <Button style={{ marginTop: "10px", marginLeft: "10px" }} type='reset' variant='contained' color='error'>Clear</Button>
                </form>
            </Paper>
        </Grid>
    );
}

export default UpdateJobs;