import { Grid, Paper } from "@mui/material";

function AdminSetting() {
    return ( 
        <Grid>
            <Paper>
                <h1>Admin Setting</h1>
            </Paper>
        </Grid>
     );
}

export default AdminSetting;