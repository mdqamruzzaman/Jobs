import { useEffect, useState } from "react";
import { getAllUsers } from "../../Services/UserServices";
import { Card, CardContent, CardMedia, Typography } from "@mui/material";

function DashbAdminDashboard() {
    const [users, SetUsers] = useState([]);

    // Get All User
    useEffect(() => {
        getAllUsers().then((response) => {
            SetUsers(response);
        })
    }, [])

    return (
        <div className="container">
            <h2>All Active Users</h2>
            <div className='row' style={{ marginTop: "10px" }}>
                {
                    users.map((user) => (
                        <div className="col-md-4">
                            <Card sx={{ maxWidth: 345 }} style={{ background: "white", marginBottom: "20px" }}>
                                <CardMedia
                                    sx={{ height: 100 }}
                                    image=""

                                />
                                <CardContent>
                                    <Typography gutterBottom variant="h5" component="div">
                                        <span style={{margin:"5px"}}><b>{user.firstname}</b></span><b>{user.lastname}</b>
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        <b>{user.username}</b>
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        Gender: <b>{user.gender}</b>
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {user.email}
                                    </Typography>
                                    <Typography variant="body2" color="text.secondary">
                                        {user.address}
                                    </Typography>
                                </CardContent>
                            </Card>
                        </div>
                    ))
                }
            </div>
        </div>
    );
}

export default DashbAdminDashboard;