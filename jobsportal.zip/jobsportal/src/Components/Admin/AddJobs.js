import { Avatar, Button, Grid, Paper, TextField, Typography } from "@mui/material";
import PostAddIcon from '@mui/icons-material/PostAdd';
import React, { useRef } from "react";
import JoditEditor from 'jodit-react';
import { addjobs } from "../../Services/JobsServices";
import Swal from 'sweetalert2';

function AddJobs() {
    const editor = useRef(null);
    const paperStyle = { padding: 20, margin: '0 auto'}
    const [description, setDescription] = React.useState('');
    const [state, setState] = React.useState({
        title: "",
        address: "",
        salary: "",
        technologyRequired: "",
        types: "",
        profilePhoto: "",
        link:""
    })
    function handleChange(event) {
        const value = event.target.value;
        setState({
            ...state,
            [event.target.name]: value
        });

    }
    const handleSubmit = (event) => {
        event.preventDefault();
        
        // store job data
        const data = {
            title: state.title,
            address: state.address,
            salary: state.salary,
            technologyRequired: state.technologyRequired,
            types: state.types,
            profilePhoto: state.profilePhoto,
            link:state.link,
            description
        }
        // call api from backend
        addjobs(data).then((response) => {
            Swal.fire('Jobs Added', '', "success");
        }).catch((error) => {
            Swal.fire(''+error.response.data.message,'','error');
        })
    }
    return (
        <Grid>
            <Paper style={paperStyle}>
                <Grid align="center">
                    <Avatar style={{ background: "blue" }}>
                        <PostAddIcon fontSize="medium" />
                    </Avatar>
                    <h2 style={{ margin: 0 }}>Add Job</h2>
                    <Typography variant="caption">Please fill this form to Add Job !</Typography>
                </Grid>
                <form onSubmit={handleSubmit}>
                    <TextField fullWidth label='Title' placeholder='Enter Company Name' variant="standard" name='title' value={state.title} type='text' required onChange={handleChange} />
                    <TextField fullWidth label='Address' placeholder="Enter Location" variant="standard" name="address" value={state.address} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Technology Required' placeholder="Enter Technology Required" variant="standard" name="technologyRequired" value={state.technologyRequired} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Types' placeholder="Enter Government or Private" variant="standard" name="types" value={state.types} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Salary' placeholder="Enter Salary" variant="standard" name="salary" value={state.salary} type="text" required onChange={handleChange} />
                    <TextField fullWidth label='Link' placeholder="Enter Apply Link" variant="standard" name="link" value={state.link} type="text" required onChange={handleChange} />
                    <JoditEditor
                        ref={editor} value={description} onBlur={newDescription => setDescription(newDescription)} onChange={newDescription => {}}
                    />
                    <TextField fullWidth label='Profile Photo' placeholder="Upload Profile Photo" variant="standard" name="profilePhoto" value={state.profilePhoto} type="file" onChange={handleChange} />

                    <Button style={{ marginTop: "10px" }} type='submit' variant='contained' color='primary'>Add Job</Button>
                    <Button style={{ marginTop: "10px", marginLeft: "10px" }} type='reset' variant='contained' color='error'>Clear</Button>
                </form>
            </Paper>
        </Grid>
    );
}

export default AddJobs;