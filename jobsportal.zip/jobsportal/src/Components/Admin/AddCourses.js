import { Grid, Paper } from "@mui/material";

function AddCourse() {
    return ( 
        <Grid>
            <Paper>
                <h1>Add Courses</h1>
            </Paper>
        </Grid>
     );
}

export default AddCourse;