import React from 'react'
import { Navigate, useLocation } from 'react-router-dom';

const AuthGuard = ({ children }) => {
    let location = useLocation();
    const token = localStorage.getItem('token');
    if (token === null) {
        return <Navigate to="/" state={{ from: location }} replace />
    }
    return children;
};
export default AuthGuard;