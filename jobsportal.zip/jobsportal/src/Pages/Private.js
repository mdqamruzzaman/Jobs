import { Grid, Paper } from "@mui/material";

function Private() {
    return (
        <Grid>
            <Paper elevation={25}>
                <h1>Private Page</h1>
            </Paper>
        </Grid>
    );
}
export default Private;