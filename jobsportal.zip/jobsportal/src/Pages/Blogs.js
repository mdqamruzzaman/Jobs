import { Grid, Paper } from "@mui/material";

function Blog() {
    return ( 
        <Grid>
            <Paper elevation={25}>
                <h1>Blogs Coming Soon!!!</h1>
            </Paper>
        </Grid>
     );
}

export default Blog;