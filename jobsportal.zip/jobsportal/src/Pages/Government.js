import { Grid, Paper } from "@mui/material";

function Government() {
    return (
        <Grid>
            <Paper elevation={25}>
                <h1>Governament</h1>
            </Paper>

        </Grid>);
}

export default Government;