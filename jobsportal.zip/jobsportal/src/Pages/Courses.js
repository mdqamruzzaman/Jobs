import { Grid, Paper } from "@mui/material";

function Courses() {
    return ( 
        <Grid>
            <Paper elevation={25}>
                <h1>All Courses Available</h1>
            </Paper>
        </Grid>
     );
}

export default Courses;