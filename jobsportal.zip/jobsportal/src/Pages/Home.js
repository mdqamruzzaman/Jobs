import SignInOutContainer from '../Container/SignInOutContainer';

function Home() {
    return (
        <div className='bootstrap-wrapper'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-9'>
                        <h3><b>Top companies hiring</b></h3>
                    </div>
                    <div className='col-md-3'>
                        <SignInOutContainer />
                    </div>
                </div>
            </div>
        </div>
    );
}

export default Home;